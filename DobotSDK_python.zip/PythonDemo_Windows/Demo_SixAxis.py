import DobotSDK as dobotSDK
from threading import Timer

#将dll读取到内存中并获取对应的CDLL实例
#Load Dll and get the CDLL object
api = dobotSDK.load()
timer_running = True

#实时获取控制器信息
#Real-time acquisition controller information 
class TimerClass():
    api = 0
    def __init__(self, api):
        self.api = api 

    def __del__(self): 
        del self.api

    def printExchange(self, inc):              
        global timer_running
        if timer_running == True :
            t = Timer(inc, self.printExchange, (inc,))
            t.start()
            exchangeList = dobotSDK.GetExchange(self.api)
            print("*************************************")
            print("ControlMode:", exchangeList[1])
            print("PowerState:", exchangeList[2])
            print("IsCollision:", exchangeList[3])
            print("JogMode:", exchangeList[4])
            print("IsAuto:", exchangeList[5])
            print("ToolCoordinate:", exchangeList[6])
            print("UserCoordinate:", exchangeList[7])
            print("Joint:", exchangeList[8])
            print("Coordinate:", exchangeList[9])
            print("Alarms:", exchangeList[10])
            print("RDN:", exchangeList[11])
            print("Arm:", exchangeList[12])
            print("DO:", exchangeList[13])
            print("DI:", exchangeList[14])
            print("*************************************")
            if len(exchangeList[10]) != 0 :
                t.cancel()
                for id,type in exchangeList[10].items():
                    print ("GetAlarmsParameter:", dobotSDK.GetAlarmsParameter(api, id, type, True))
            

#建立与dobot的连接
#Connect Dobot
resultConnect = dobotSDK.ConnectDobot(api, "192.168.1.6")
print("resultConnect", resultConnect)
if resultConnect == 0:
    print("Connect Dobot Success!")
    versionInfo = dobotSDK.GetDobotVersion(api)
    print("Current Version is", versionInfo)
    commonSpeed = dobotSDK.GetRapidRate(api)
    print("Current speed percentage is", commonSpeed)
    tool = dobotSDK.GetCoordinateToolIndex(api)
    print("tool index:", tool)
    user = dobotSDK.GetCoordinateUserIndex(api)
    print("user index:", user)
    dobotSDK.SetControlMode(api, 1)
    #等待使能成功
    #Wait Enable ControlMode Success
    dobotSDK.dSleep(8000)
    #开启定时器
    #Start timer
    TimerClass(api).printExchange(0.5)
    for i in range(0,3):
        #MovJ 接口参数可修改，默认参数:tool = 0, user = 0, rdnList = [-1, -1, -1, -1], arm = 0, isBlock = False
        #MovJ interface parameters can be modified, default parameters:tool = 0, user = 0, rdnList = [-1, -1, -1, -1], arm = 0, isBlock = False
        #运动点位可修改，当报警出现时需更改点位
        #pointList can be modified, when the alarm appears, change the point.
        resultStart = dobotSDK.MovJ(api, [358, -94, 720, -85, -30, -100], isBlock = True)
        print("resultStart", resultStart)
        resultEnd = dobotSDK.MovJ(api, [246, 276, 720, -85, -30, -38], isBlock = True)
        print("resultEnd", resultEnd)
    timer_running = False
    #断开与Dobot连接
    #Disconnect Dobot
    dobotSDK.DisconnectDobot(api)